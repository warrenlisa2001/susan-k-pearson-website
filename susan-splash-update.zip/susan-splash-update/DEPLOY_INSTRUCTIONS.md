# Susan K Pearson — Daisy Logo + Blooming Entrance Splash (v3 — FINAL)

Production build compiles clean. Drop straight into `warrenlisa2001/susan-k-pearson-website`.

## What's new in v3

The daisy on the homepage splash now actually **blooms open** on load, instead of sitting static:

1. The whole flower tilts up toward the viewer out of a folded, foreshortened bud (a 3D rotateX +
   scale entrance) — the "4D" dimensional opening feel.
2. The 8 outer petals unfurl first, one after another with a soft spring overshoot, like guard
   petals peeling back.
3. The 8 inner petals unfurl right behind them, revealing the second layer.
4. The gold center blooms into view last, popping slightly past full size before settling — the
   heart of the flower opening last.
5. Once the bloom finishes (~1.6s), it settles into the slow ambient breathing + rotation from
   before, so it stays alive without competing for attention.

It's a one-time entrance sequence — plays once per session, same as the gate itself. Motion is
fully disabled for anyone with "reduce motion" turned on (the flower just appears fully bloomed,
no animation).

Logo files and splash copy are unchanged from the last version — still the richer layered daisy
mark, still "Stop carrying what was never yours to hold."

## How to apply it

```bash
cp src/index.tsx <path-to-this-folder>/src/index.tsx
cp <path-to-this-folder>/public/images/skp-logo-white.png public/images/skp-logo-white.png
cp <path-to-this-folder>/public/images/skp-brand-logo.png public/images/skp-brand-logo.png

npm run build
./.cloudflare-deploy.sh

git add src/index.tsx public/images/skp-logo-white.png public/images/skp-brand-logo.png
git commit -m "Daisy blooms open on the homepage entrance splash"
git push
```

Nothing else in the repo touched.
